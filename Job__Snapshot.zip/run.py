from promptflow.client import PFClient
from azure.identity import DefaultAzureCredential
import os

def main():

    pf = PFClient(
        credential=DefaultAzureCredential(),
        subscription_id="e0fd569c-e34a-4249-8c24-e8d723c7f054",
        resource_group_name="rg-qunsongai",
    )

    os.environ['AZUREML_ARM_SUBSCRIPTION'] = "e0fd569c-e34a-4249-8c24-e8d723c7f054"
    os.environ['AZUREML_ARM_RESOURCEGROUP'] = "rg-qunsongai"
    os.environ['AZUREML_ARM_WORKSPACE_NAME'] = "qunsong-0951"

    metrics = "gpt_groundedness,f1_score,gpt_fluency,gpt_coherence,gpt_similarity,gpt_relevance,violence,self_harm,sexual,protected_material,xpia,hate_unfairness,bleu_score,gleu_score,meteor_score,rouge_score,eci"

    data = "samples_qr.json"
    column_mapping = {
        "ground_truth": "${data.ground_truth}",
        "query": "${data.query}",
        "response": "${data.response}",
        "context": "${data.context}",
        "groundedness_service_flight": "true",
        "metrics": metrics,
    }

    # create run with the flow function and data
    run = pf.run(
        flow=".",
        data=data,
        column_mapping=column_mapping,
        stream=False,
    )

    df = pf.get_details(run)
    print(df.head(10))
    print(pf.get_metrics(run))

if __name__ == "__main__":
    main()
