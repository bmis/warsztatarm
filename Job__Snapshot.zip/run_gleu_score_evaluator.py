from promptflow import tool
from azure.ai.evaluation import GleuScoreEvaluator


@tool
def compute_gleu_score(ground_truth: str, response: str) -> str:
    eval_fun = GleuScoreEvaluator()
    return eval_fun(response=response, ground_truth=ground_truth)
