from promptflow import tool
from azure.ai.evaluation import RougeScoreEvaluator, RougeType


@tool
def compute_rouge_score(rouge_type: str, ground_truth: str, response: str) -> str:
    rouge_type_enum = {member.value: member for member in RougeType}.get(rouge_type)
    eval_fun = RougeScoreEvaluator(rouge_type=rouge_type_enum)
    result = eval_fun(response=response, ground_truth=ground_truth)
    return result
