from promptflow import tool
from azure.identity import DefaultAzureCredential
from azure.ai.evaluation import SelfHarmEvaluator
from utils import get_current_azure_ai_project


@tool
def run_selfharm_evaluator(query: str, response: str):
    azure_ai_project = get_current_azure_ai_project()
    eval_fn = SelfHarmEvaluator(DefaultAzureCredential(), azure_ai_project=azure_ai_project)
    result = eval_fn(
        query=query,
        response=response,
    )
    return result
