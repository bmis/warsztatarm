from promptflow import tool
from azure.identity import DefaultAzureCredential
from azure.ai.evaluation import HateUnfairnessEvaluator
from utils import get_current_azure_ai_project


@tool
def run_hate_unfairness_evaluator(query: str, response: str):
    azure_ai_project = get_current_azure_ai_project()
    eval_fn = HateUnfairnessEvaluator(azure_ai_project=azure_ai_project, credential=DefaultAzureCredential())
    result = eval_fn(
        query=query,
        response=response,
    )
    return result

