from promptflow import tool
from azure.ai.evaluation import BleuScoreEvaluator


@tool
def compute_bleu_score(ground_truth: str, response: str) -> str:
    eval_fun = BleuScoreEvaluator()
    return eval_fun(response=response, ground_truth=ground_truth)
