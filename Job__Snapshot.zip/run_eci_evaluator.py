from promptflow import tool
from azure.identity import DefaultAzureCredential
from azure.ai.evaluation._evaluators._eci._eci import ECIEvaluator as evaluator
from utils import get_current_azure_ai_project


@tool
def run_eci_evaluator(query: str, response: str):
    azure_ai_project = get_current_azure_ai_project()
    eval_fn = evaluator(azure_ai_project=azure_ai_project, credential=DefaultAzureCredential())
    return eval_fn(
        query=query,
        response=response,
    )
