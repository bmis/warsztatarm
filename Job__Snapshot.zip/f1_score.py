from promptflow import tool
from azure.ai.evaluation import F1ScoreEvaluator


@tool
def compute_f1_score(ground_truth: str, response: str) -> str:
    eval_fun = F1ScoreEvaluator()
    return eval_fun(response=response, ground_truth=ground_truth)
